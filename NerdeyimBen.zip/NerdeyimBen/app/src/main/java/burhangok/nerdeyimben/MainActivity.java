package burhangok.nerdeyimben;

import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import br.com.safety.locationlistenerhelper.core.CurrentLocationListener;
import br.com.safety.locationlistenerhelper.core.CurrentLocationReceiver;
import br.com.safety.locationlistenerhelper.core.LocationTracker;

public class MainActivity extends AppCompatActivity {

    private LocationTracker locationTracker;

    public Double latValue,longValue;
    Button gosterB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        init();
        locationTracker=new LocationTracker("my.action")
                .setInterval(50000)
                .setGps(true)
                .setNetWork(false)
                .currentLocation(new CurrentLocationReceiver(new CurrentLocationListener() {
                    @Override
                    public void onCurrentLocation(Location location) {
                        latValue=location.getLatitude();
                        longValue=location.getLongitude();

                        Log.d("Konum Bilgisi Enlem: ",Double.toString(location.getLatitude()));
                        Log.d("Konum Bilgisi Boylam: ",Double.toString(location.getLongitude()));

                    }

                    @Override
                    public void onPermissionDiened() {

                    }
                })).start(getBaseContext(),this);


        gosterB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri geoInfo = Uri.parse("geo:"+latValue+","+longValue);
                Intent toMap = new Intent(Intent.ACTION_VIEW,geoInfo);
                startActivity(toMap);

            }
        });

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        locationTracker.onRequestPermission(requestCode, permissions, grantResults);
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locationTracker.stopLocationService(this);
    }


    void init() {

        gosterB =findViewById(R.id.showMe);
    }
}
